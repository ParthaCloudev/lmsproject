import boto3

s3 = boto3.client('s3')
BUCKET_NAME = 'imageprocessin2'

def lambda_handler(event, context):
    try:
        for record in event['Records']:
            key = record['s3']['object']['key']
            if not key.startswith('raw2/'):
                continue
            new_key = key.replace('raw2/', 'processed2/', 1)
            s3.copy_object(
                Bucket=BUCKET_NAME,
                CopySource={'Bucket': BUCKET_NAME, 'Key': key},
                Key=new_key,
                MetadataDirective='REPLACE',
                ContentType='image/jpeg'
            )
        return {'statusCode': 200, 'body': 'Copied successfully'}
    except Exception as e:
        return {'statusCode': 500, 'body': str(e)}
