import boto3
import base64
import uuid

s3 = boto3.client('s3')
BUCKET_NAME = 'imageprocessin2'
RAW_FOLDER = 'raw2/'

def lambda_handler(event, context):
    try:
        body = event['body']
        if event.get('isBase64Encoded'):
            body = base64.b64decode(body)
        file_name = f"{RAW_FOLDER}image_{uuid.uuid4()}.jpg"
        s3.put_object(Bucket=BUCKET_NAME, Key=file_name, Body=body, ContentType='image/jpeg')
        return {
            'statusCode': 200,
            'body': f"Uploaded: s3://{BUCKET_NAME}/{file_name}"
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }
